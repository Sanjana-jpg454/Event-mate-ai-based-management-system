package com.eventmate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventMateApplication {
    public static void main(String[] args) {
        SpringApplication.run(EventMateApplication.class, args);
    }
}
